# hw-base

The base for homeworks.
This README will be copied for each homework.

# Reading Markdown files
Before you start doing anything, please make sure you have a proper way of reading markdown files.
You can use any tool you would like for it.
Python IDEs that we recommend (VSCode or PyCharm), which come with Markdown readers built-in.


# Setup

**You only need to do setup once**, then for future homeworks you can run `conda activate ml`.

## Miniconda installation
Before you start working with this repo, you should install Anaconda.

**Before clicking in the link below** read notes below:

* Linux/Mac OS:
  * If using Linux/Mac please install command line version.
  * Make sure that you choose to initialize conda at startup.
    This will lead to fewer headaches in the future
* Windows:
  * If using Windows, we recommend using the Anaconda Terminal, which uses Bash-like syntax. 
* Low storage system
  * If you are low of storage (<10GB; for example attu), then Miniconda (see link below) might be a better option.

### Download links

[Anaconda (default)](https://www.anaconda.com/products/individual#Downloads)

[Miniconda](https://docs.conda.io/en/latest/miniconda.html#latest-miniconda-installer-links) (if running low on disk space)

You can find more detailed instructions for installation [at this link](https://docs.conda.io/projects/conda/en/latest/user-guide/install/index.html#installing-conda-on-a-system-that-has-other-python-installations-or-packages).

## Environment Setup
First make sure you have at least ~5GB of free drive.
Then, from this directory, run:
```
conda env create -f environment.yaml
conda activate ml
```

*Note*: The first command may take long time, especially if your connection is slow.

**Then, whenever you come back to work on homeworks,** just run: `conda activate ml`.

![A quite long gif visualizing how to setup enviornment](./README_media/setup-env.gif)

### IDE setup

You can to use any IDE as you would like.
Two popular for python are: VSCode (Microsoft) and PyCharm (JetBrains).

#### PyCharm
PyCharm is tailor made for Python, so the setup should be minimal.

Just make sure you point python interpreter to the right path for the project.
To do so, you should follow [these instructions](https://www.jetbrains.com/help/pycharm/configuring-python-interpreter.html#add-existing-interpreter).

> Please note, that to run linting you will need to use terminal, and run `inv lint`. You can try setting up linters through *External Programs* section.

#### VSCode
VSCode is general purpose IDE, so you will need to install *Python* and *Pylance* extensions (both by Microsoft).


To setup python interpreter, [follow these instructions](https://code.visualstudio.com/docs/python/environments#_select-and-activate-an-environment)
or first reload VSCode, open a folder with homework downloaded and unzipped.

Now whenever you open terminal it should say "folder you opened" on the left hand side,
and `which python` (Unix based systems) or `where python` (cmd or powershell terminals) should also output path with in it.
Sometimes, it doesn't work with the first terminal after VSCode opens, so `exit` it and reopen it (Ctrl+J).
**NOTE** For further debugging see "Debugging" subsection couple of paragraphs below.

##### **Debugging**
* If `which python` doesn't return path with `ml` in it, and restarting terminal doesn't work, there might be an issue with settings in VSCode. It may be because of VS Code's setting, namely the inherited environment of the integrated terminal ("Terminal > Integrated: Inherit Env"). Turn it off, and reopen VS Code to see if the issue has been resolved.

Most errors with running code have to do with making sure the cse446 environment is properly activated and being used. We've provided below some debugging tips for commonly seen errors. The discussion board, office hours, and stack overflow are great places to get additional help if you get stuck!

* If you run into an error when setting up the environment, try setting the channel priority differently (see [this post](https://stackoverflow.com/questions/63734508/stuck-at-solving-environment-on-anaconda)).

* If you run into the error `The term inv is not recognized as a cmdlet, function, script, or operable program`:
  * Most likely, the ml environment has not been activated properly. If you haven't run `conda activate ml`, start there. If you have and it still isn't working, and you are on a Windows machine, check which terminal you are running in. You may find that the Anaconda Terminal or the Windows command prompt are better options than powershell (see below for using conda with powershell). 

* If you run into the error `No module named [x]`:
  * This also may be indicative of the environment not being activated/used properly. See the above tip to make sure the environment can be activated.
  * Also confirm that you have selected the correct Python interpreter if you are using VSCode (see the VSCode section above).
  * Confirm that when you run your code, the correct Python version and environment is being used (check `python -V` and `which python`/`where python`). Try using the "run" (play) button if using the `python` command in your terminal is not working.
  * If you are confident that the cse446 environment is being used properly and are still getting a `no module` error, we recommend either of two solutions:
    * Removing the existing ml environment using `conda env remove -n ml` (after deactivating the environment) and reinstalling the environment from scratch.
    * Check the installed packages in the ml environment using `conda list`. Uninstall and install specific modules based on the error messages.
  * Some students have had success running `pip install -e .` from the homework directory (in the activated ml environment).

* For those using Windows and wanting to use powershell rather than the Anaconda Terminal, or if you are running into the error `conda command is not recognized`, you may find the following posts to be useful:
  * [Activating conda environment from powershell](https://stackoverflow.com/questions/64149680/how-to-activate-conda-environment-from-powershell) 
  * [Conda not being recognized on Windows](https://stackoverflow.com/questions/44597662/)